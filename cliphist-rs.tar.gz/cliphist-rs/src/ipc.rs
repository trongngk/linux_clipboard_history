use crate::util::socket_path;
use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::sync::mpsc::{channel, Sender};
use std::time::Duration;

/// Yêu cầu gửi từ picker sang daemon.
pub enum Req {
    /// Đặt entry id vào clipboard; trả lời qua Sender.
    Set(i64, Sender<String>),
}

/// Mở socket và lắng nghe trong thread riêng.
pub fn serve(tx: Sender<Req>) -> std::io::Result<()> {
    let path = socket_path();
    let _ = std::fs::remove_file(&path);
    let listener = UnixListener::bind(&path)?;
    crate::util::chmod(&path, 0o600);

    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let Ok(mut stream) = stream else { continue };
            let tx = tx.clone();
            std::thread::spawn(move || {
                let _ = stream.set_read_timeout(Some(Duration::from_secs(5)));
                let mut line = String::new();
                let mut reader = BufReader::new(match stream.try_clone() {
                    Ok(s) => s,
                    Err(_) => return,
                });
                if reader.read_line(&mut line).is_err() {
                    return;
                }
                let reply = handle(line.trim(), &tx);
                let _ = writeln!(stream, "{}", reply);
                let _ = stream.flush();
            });
        }
    });
    Ok(())
}

fn handle(line: &str, tx: &Sender<Req>) -> String {
    let mut parts = line.splitn(2, ' ');
    match (parts.next(), parts.next()) {
        (Some("PING"), _) => "OK".into(),
        (Some("SET"), Some(arg)) => match arg.trim().parse::<i64>() {
            Ok(id) => {
                let (rtx, rrx) = channel();
                if tx.send(Req::Set(id, rtx)).is_err() {
                    return "ERR daemon bận".into();
                }
                rrx.recv_timeout(Duration::from_secs(3))
                    .unwrap_or_else(|_| "ERR timeout".into())
            }
            Err(_) => "ERR id không hợp lệ".into(),
        },
        _ => "ERR lệnh lạ".into(),
    }
}

/// Phía picker: nhờ daemon đặt clipboard. Err nghĩa là daemon không sẵn sàng.
pub fn client_set(id: i64) -> Result<(), String> {
    let mut stream = UnixStream::connect(socket_path()).map_err(|e| e.to_string())?;
    stream
        .set_read_timeout(Some(Duration::from_secs(3)))
        .map_err(|e| e.to_string())?;
    writeln!(stream, "SET {}", id).map_err(|e| e.to_string())?;
    stream.flush().map_err(|e| e.to_string())?;
    let mut line = String::new();
    BufReader::new(&stream)
        .read_line(&mut line)
        .map_err(|e| e.to_string())?;
    if line.trim() == "OK" {
        Ok(())
    } else {
        Err(line.trim().to_string())
    }
}

pub fn daemon_alive() -> bool {
    UnixStream::connect(socket_path())
        .map(|mut s| {
            let _ = s.set_read_timeout(Some(Duration::from_millis(500)));
            let _ = writeln!(s, "PING");
            let mut line = String::new();
            BufReader::new(&s).read_line(&mut line).is_ok() && line.trim() == "OK"
        })
        .unwrap_or(false)
}
