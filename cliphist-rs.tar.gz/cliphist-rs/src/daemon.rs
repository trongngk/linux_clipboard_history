use crate::clip::{Clip, Grab};
use crate::db;
use crate::ipc::{self, Req};
use crate::util::*;
use std::sync::mpsc::{channel, RecvTimeoutError};
use std::time::Duration;

const FULL_CHECK_EVERY: u64 = 5;

pub fn run(interval_ms: u64) -> Result<(), String> {
    let _lock = match acquire_lock(&daemon_lock()).map_err(|e| e.to_string())? {
        LockResult::Acquired(l) => l,
        LockResult::Held(pid) => {
            return Err(match pid {
                Some(p) => format!("daemon đã chạy rồi (pid {p}). Dừng bằng: kill {p}"),
                None => "daemon đã chạy rồi".into(),
            })
        }
    };

    let clip = Clip::new()?;
    let con = db::open().map_err(|e| e.to_string())?;
    let mut rules = db::load_ignore_rules();
    let mut rules_mtime = mtime(&ignore_file());

    let (tx, rx) = channel::<Req>();
    ipc::serve(tx).map_err(|e| format!("mở socket thất bại: {e}"))?;
    eprintln!(
        "[{APP}] daemon chạy (interval={}ms, db={}, sock={})",
        interval_ms,
        db_path().display(),
        socket_path().display()
    );

    let mut last_token: (Option<Vec<u8>>, Option<u32>) = (None, None);
    let mut tick: u64 = 0;

    capture(&clip, &con, &rules);

    loop {
        // chờ tới lượt poll kế tiếp, nhưng bị đánh thức ngay khi picker gửi SET
        match rx.recv_timeout(Duration::from_millis(interval_ms)) {
            Ok(Req::Set(id, reply)) => {
                let msg = match db::get(&con, id) {
                    Ok(Some(e)) => match clip.put(&e) {
                        Ok(()) => {
                            // clipboard giờ do chính mình sở hữu; vòng sau sẽ đọc lại
                            // và dedupe theo hash đưa entry đó lên đầu
                            last_token = (None, None);
                            "OK".to_string()
                        }
                        Err(e) => format!("ERR {e}"),
                    },
                    Ok(None) => format!("ERR không có entry id={id}"),
                    Err(e) => format!("ERR {e}"),
                };
                let _ = reply.send(msg);
                continue;
            }
            Err(RecvTimeoutError::Disconnected) => {}
            Err(RecvTimeoutError::Timeout) => {}
        }

        tick += 1;
        if pause_flag().exists() {
            continue;
        }

        let mt = mtime(&ignore_file());
        if mt != rules_mtime {
            rules = db::load_ignore_rules();
            rules_mtime = mt;
        }

        let token = clip.change_token();
        if token.1.is_none() {
            continue; // không ai sở hữu clipboard
        }
        if token != last_token {
            last_token = token;
            capture(&clip, &con, &rules);
        } else if last_token.0.is_none() && tick % FULL_CHECK_EVERY == 0 {
            // owner không trả TIMESTAMP: quét lại định kỳ cho chắc.
            // Trùng nội dung thì dedupe theo hash, chỉ update ts.
            capture(&clip, &con, &rules);
        }
    }

    #[allow(unreachable_code)]
    {
        drop(_lock);
        Ok(())
    }
}

fn capture(clip: &Clip, con: &rusqlite::Connection, rules: &[regex::Regex]) {
    match clip.grab() {
        Grab::Text(t) => {
            if let Err(e) = db::store_text(con, &t, rules) {
                eprintln!("[{APP}] lưu text lỗi: {e}");
            }
        }
        Grab::Image(data, mime) => {
            if let Err(e) = db::store_image(con, &data, mime) {
                eprintln!("[{APP}] lưu ảnh lỗi: {e}");
            }
        }
        Grab::Empty => {}
    }
}

fn mtime(p: &std::path::Path) -> u64 {
    std::fs::metadata(p)
        .and_then(|m| m.modified())
        .ok()
        .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
        .map(|d| d.as_secs())
        .unwrap_or(0)
}
