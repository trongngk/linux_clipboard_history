# Hướng dẫn cài đặt cliphist

Clipboard history kiểu Win+V cho Linux Mint / Cinnamon. Lưu text và ảnh, mở bằng
`Super+V`, giữ 20 bản ghi gần nhất.

Toàn bộ hướng dẫn này giả định Mint 21 hoặc 22 với Cinnamon trên X11 (mặc định
của Mint). Kiểm tra nhanh:

```bash
echo $XDG_SESSION_TYPE       # phải ra: x11
echo $XDG_CURRENT_DESKTOP    # phải có: X-Cinnamon
```

Nếu ra `wayland` thì tool này chưa dùng được — cơ chế đọc clipboard dựa trên X11
selection.

---

## 1. Cài gói cần thiết

```bash
sudo apt update
sudo apt install cargo build-essential pkg-config libgtk-3-dev xdotool
```

| Gói | Để làm gì |
|---|---|
| `cargo`, `build-essential` | biên dịch Rust và SQLite kèm theo |
| `pkg-config`, `libgtk-3-dev` | header GTK3 để build phần giao diện |
| `xdotool` | tự nhấn Ctrl+V sau khi chọn, và nhớ cửa sổ đang gõ |

`xclip` không bắt buộc — chỉ dùng làm phương án dự phòng khi daemon không chạy.

Kiểm tra toolchain:

```bash
cargo --version     # Mint 22 ra 1.75.0, Mint 21 ra 1.66–1.7x đều được
```

---

## 2. Biên dịch

```bash
tar xzf cliphist-rs.tar.gz
cd cliphist-rs
cargo build --release
```

Lần đầu mất khoảng **2–4 phút** (phải compile SQLite, toàn bộ gtk-rs, rồi LTO ở
cuối). Xong sẽ thấy:

```
    Finished release [optimized] target(s) in 2m21s
```

> **Đừng chạy `cargo update`.** File `Cargo.lock` đã ghim version cho toolchain
> cũ; các bản mới của `indexmap`, `toml_edit`, `serde` yêu cầu `edition2024` mà
> cargo 1.75 không đọc được.

---

## 3. Đưa binary vào PATH

```bash
install -Dm755 target/release/cliphist ~/.local/bin/cliphist
cliphist --help
```

Nếu shell báo `command not found`, `~/.local/bin` chưa nằm trong PATH:

```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc   # zsh thì ~/.zshrc
exec $SHELL
```

---

## 4. Bật autostart và hotkey

```bash
cliphist install
```

Lệnh này làm hai việc:

- ghi `~/.config/autostart/cliphist-lite.desktop` để daemon tự chạy mỗi lần đăng nhập
- gán `Super+V` qua `gsettings org.cinnamon.desktop.keybindings`, tự tìm slot
  `customN` còn trống nên **không đè shortcut sẵn có** của bạn

Muốn phím khác: `cliphist install --hotkey '<Super>c'`.

Chạy daemon ngay cho lần này (lần sau autostart tự lo):

```bash
nohup cliphist daemon >/tmp/cliphist.log 2>&1 &
```

---

## 5. Kiểm tra

```bash
cliphist doctor
```

Kỳ vọng:

```
DISPLAY        = :0
xdotool        = /usr/bin/xdotool
daemon         = đang chạy
X11 clipboard  = OK (TIMESTAMP: có)
DB             = /home/<user>/.local/share/cliphist-lite/history.db (0 text, 0 ảnh)
max-entries    = 20 (mục đã ghim không bị tính)
```

Rồi copy vài đoạn text, một tấm ảnh, và:

```bash
cliphist list
```

Thấy danh sách là xong. Nhấn `Super+V` để mở panel.

---

## 6. Dùng panel

| Phím | Việc |
|---|---|
| gõ chữ | lọc (nhiều từ khoá, phải khớp tất cả) |
| `↑` `↓` | di chuyển |
| `PgUp` `PgDn` | nhảy 5 mục |
| `Enter` hoặc click card | chép và tự dán |
| `Alt+1` … `Alt+9` | chọn nhanh theo số ghi trên card |
| `Ctrl+P` | ghim (mục ghim luôn nằm trên đầu, không bị xoá theo hạn mức) |
| `Delete` | xoá mục đang chọn |
| `Esc`, click ra ngoài, hoặc `Super+V` lần nữa | đóng |

---

## 7. Tuỳ chỉnh

```bash
cliphist set max-entries 50      # đổi số bản ghi giữ lại (mặc định 20)
cliphist set blur-close off      # click ra ngoài KHÔNG đóng panel
cliphist pause                   # tạm dừng ghi (trước khi share màn hình)
cliphist resume
```

Đổi `max-entries` áp dụng ngay, không cần restart daemon.

### Không ghi những thứ nhạy cảm

Sửa `~/.config/cliphist-lite/ignore.txt`, mỗi dòng một regex; nội dung khớp sẽ
không được lưu. File đã có sẵn mẫu, chỉ cần bỏ dấu `#`:

```
^ghp_[A-Za-z0-9]{36}$
^sk-[A-Za-z0-9]{20,}$
-----BEGIN [A-Z ]*PRIVATE KEY-----
^eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.
```

File được reload nóng, không cần restart. Lưu ý crate `regex` của Rust **không
hỗ trợ lookahead/lookbehind/backreference** — pattern kiểu `(?=...)` sẽ bị bỏ
qua kèm cảnh báo trong log.

---

## 8. Đang dùng bản Python thì chuyển sang thế nào

Database tương thích hoàn toàn, lịch sử cũ giữ nguyên (schema tự migrate). Chỉ
cần tắt bản cũ để hai daemon không cùng ghi:

```bash
pkill -f 'cliphist.py daemon'
rm -f ~/.config/autostart/cliphist-lite.desktop
cliphist install                 # ghi lại autostart + hotkey trỏ vào binary mới
nohup cliphist daemon >/tmp/cliphist.log 2>&1 &
```

Lưu ý bản Rust mặc định giữ 20 bản ghi, còn bản Python giữ 500 — lần trim đầu
tiên sẽ xoá phần dư. Muốn giữ nhiều hơn thì chạy `cliphist set max-entries 500`
**trước** khi copy thêm gì.

---

## 9. Cập nhật và gỡ

```bash
# cập nhật
cd cliphist-rs && cargo build --release
install -Dm755 target/release/cliphist ~/.local/bin/cliphist
pkill -f 'cliphist daemon' && nohup cliphist daemon >/tmp/cliphist.log 2>&1 &
```

Không cần chạy lại `install` nếu đường dẫn binary không đổi.

```bash
# gỡ
cliphist uninstall               # bỏ autostart
pkill -f 'cliphist daemon'
rm -rf ~/.local/share/cliphist-lite ~/.config/cliphist-lite ~/.local/bin/cliphist
```

Hotkey xoá tay trong **Settings → Keyboard → Shortcuts → Custom Shortcuts**.

---

## 10. Xử lý sự cố

| Hiện tượng | Nguyên nhân | Cách xử lý |
|---|---|---|
| `The system library 'gtk+-3.0' was not found` | thiếu header GTK | `sudo apt install libgtk-3-dev pkg-config` |
| `error: linker 'cc' not found` | thiếu compiler | `sudo apt install build-essential` |
| `feature 'edition2024' is required` | `Cargo.lock` bị mất hoặc bị `cargo update` ghi đè | giải nén lại tarball, đừng chạy `cargo update` |
| `command not found: cargo` | chưa có Rust | `sudo apt install cargo` |
| `Super+V` không phản ứng | daemon chưa chạy, hoặc hotkey trùng | `cliphist doctor`; kiểm tra Settings → Keyboard → Shortcuts |
| Panel mở nhưng trống | daemon chưa ghi được gì | `cliphist list`; xem `/tmp/cliphist.log` |
| Chọn xong không tự dán | thiếu `xdotool`, hoặc app đích không nhận Ctrl+V | `sudo apt install xdotool`; dán tay bằng Ctrl+V |
| Panel tự đóng sai lúc | tuỳ WM | `cliphist set blur-close off`, hoặc chẩn đoán bằng `CLIPHIST_DEBUG=1 cliphist pick` |
| `daemon đã chạy rồi (pid N)` | đã có instance | bình thường; muốn khởi động lại thì `kill N` trước |
| Ảnh dán được vào app này, không được app kia | app chỉ nhận `image/png` mà ảnh gốc là jpeg | chưa hỗ trợ; convert khi lưu là cách sửa |

Log daemon nằm ở nơi bạn redirect (`/tmp/cliphist.log` theo hướng dẫn trên).
Chạy foreground để xem trực tiếp:

```bash
pkill -f 'cliphist daemon'
cliphist daemon        # Ctrl+C để dừng
```

---

## 11. Dữ liệu nằm ở đâu

```
~/.local/share/cliphist-lite/history.db     SQLite, chmod 600
~/.local/share/cliphist-lite/images/        ảnh, tên = sha256, chmod 600
~/.config/cliphist-lite/ignore.txt          regex loại trừ
~/.config/cliphist-lite/settings.conf       max_entries, blur_close
~/.config/autostart/cliphist-lite.desktop   autostart
$XDG_RUNTIME_DIR/cliphist-lite.sock         socket picker ↔ daemon
```

`history.db` là **plaintext**. Nó chmod 600 trong `$HOME`, nhưng mọi tiến trình
chạy dưới user của bạn đều đọc được — hãy coi nó như một file secret, và dùng
`cliphist pause` cùng `ignore.txt` khi làm việc với credential.
