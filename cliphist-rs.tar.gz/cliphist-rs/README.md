# cliphist — clipboard history cho Linux Mint / Cinnamon

> Hướng dẫn cài từng bước: [HUONG-DAN-CAI.md](HUONG-DAN-CAI.md)

> Cài đặt từng bước: xem [HUONG-DAN-CAI-DAT.md](HUONG-DAN-CAI-DAT.md)

Bản Rust của tool clipboard history kiểu Win+V. Lưu cả text và ảnh, panel GTK3
mở cạnh con trỏ, hotkey `Super+V`.

## Build

```bash
sudo apt install build-essential pkg-config libgtk-3-dev xdotool
cargo build --release
```

Binary nằm ở `target/release/cliphist` (~3.7 MB). Toolchain của Mint (`sudo apt
install cargo`, rustc 1.75) build được — các version trong `Cargo.lock` đã ghim
sẵn cho toolchain đó, đừng chạy `cargo update` nếu không có rustup bản mới.

## Cài

```bash
install -Dm755 target/release/cliphist ~/.local/bin/cliphist
cliphist install                 # autostart + hotkey Super+V (gsettings Cinnamon)
nohup cliphist daemon >/tmp/cliphist.log 2>&1 &
cliphist doctor                  # kiểm tra môi trường
```

Đổi hotkey: `cliphist install --hotkey '<Super>c'`.

## Lệnh

| Lệnh | Việc |
|---|---|
| `cliphist daemon [--interval MS]` | chạy nền: ghi lịch sử + giữ X selection (mặc định 400ms) |
| `cliphist pick [--paste] [--stay]` | mở panel; `--paste` tự Ctrl+V sau khi chọn; `--stay` thì click ra ngoài không đóng |
| `cliphist set blur-close on\|off` | đặt mặc định cho việc click ra ngoài (khỏi phải sửa hotkey) |
| `cliphist set max-entries N` | số bản ghi giữ lại (mặc định 20); áp dụng ngay |
| `cliphist set max-entries N` | số bản ghi giữ lại, mặc định 20; áp dụng ngay |
| `cliphist list [-n N]` | in lịch sử |
| `cliphist get <id>` | in nội dung (ảnh: in đường dẫn file) |
| `cliphist copy <id>` | chép entry vào clipboard |
| `cliphist wipe [--all]` | xoá lịch sử; `--all` xoá cả mục đã ghim |
| `cliphist pause` / `resume` | tạm dừng / bật lại việc ghi |
| `cliphist doctor` | kiểm tra DISPLAY, binary phụ, daemon, DB |
| `cliphist uninstall` | gỡ autostart |

## Phím trong panel

Gõ để lọc, `↑↓` chọn, `PgUp/PgDn` nhảy 5, `Enter` chép, `Alt+1..9` chọn nhanh,
`Ctrl+P` ghim, `Delete` xoá, `Esc` đóng. Click vào card cũng chọn luôn. Nhấn
`Super+V` lần nữa cũng đóng panel.

**Click ra ngoài panel thì đóng.** Cơ chế: panel grab con trỏ + bàn phím giống
cách GTK làm với menu và popover, nhờ `owner_events=true` nên widget con vẫn
nhận event bình thường, còn click ngoài panel được gửi tới panel với toạ độ root
nằm ngoài khung — đó là dấu hiệu để đóng.

Không dùng `focus-out-event` làm cơ chế chính vì panel không có decoration, WM
(Muffin) có khi không bao giờ trao focus theo nghĩa nó hiểu, và ngược lại
focus-out cũng phát khi focus chỉ chuyển tạm sang popup con — đóng oan. Nó chỉ
còn là fallback khi grab thất bại.

Vì panel giữ grab, có hai chốt an toàn: nhả grab + huỷ cửa sổ **trước** khi gửi
Ctrl+V (không thì phím bị grab chặn lại hoặc bay vào chính panel), và tự đóng
sau 120 giây.

Không thích tự đóng khi click ra ngoài:

```bash
cliphist set blur-close off     # hoặc chỉ một lần: cliphist pick --stay
```

## Kiến trúc

Khác bản Python một điểm quan trọng: **X11 bắt buộc tiến trình sở hữu selection
phải còn sống**. Bản Python nhờ `xclip` (nó tự fork nền) nên không phải nghĩ.
Bản này daemon tự giữ selection:

```
picker (sống ~2 giây)  ──unix socket──>  daemon (sống mãi)  ──> X selection owner
   $XDG_RUNTIME_DIR/cliphist-lite.sock       "SET <id>"
```

Nếu daemon không chạy, picker fallback về `xclip`. Vì vậy `xclip` chỉ là tuỳ
chọn, không bắt buộc.

Phát hiện clipboard đổi qua hai dấu hiệu rẻ, không phải đọc lại nội dung:

1. target `TIMESTAMP` của selection
2. cửa sổ đang sở hữu clipboard (`GetSelectionOwner`)

Cần cả hai vì không phải app nào cũng trả `TIMESTAMP` — `xclip` là một ví dụ.
Nhờ vậy ảnh vài MB không bị đọc lại mỗi vòng lặp.

## Dữ liệu

```
~/.local/share/cliphist-lite/history.db     SQLite (chmod 600)
~/.local/share/cliphist-lite/images/        ảnh, tên file = sha256 (chmod 600)
~/.config/cliphist-lite/ignore.txt          regex loại trừ, reload nóng
```

DB **tương thích với bản Python** — chạy song song hay đổi qua đổi lại đều được,
schema tự migrate.

Giới hạn: **20 bản ghi** tính chung text và ảnh (`cliphist set max-entries N` để
đổi), text tối đa 200 KB, ảnh tối đa 20 MB. Mục đã ghim **không** tính vào hạn
mức và không bị trim. Xoá entry thì file ảnh mồ côi cũng bị dọn.

## ignore.txt

Mỗi dòng một regex; nội dung khớp sẽ không được lưu. Hữu ích khi copy token,
cookie, private key trong lúc test. Lưu ý crate `regex` của Rust **không hỗ trợ
lookahead/lookbehind/backreference** — nếu bạn có pattern kiểu `(?=...)` từ bản
Python thì phải viết lại, daemon sẽ in cảnh báo và bỏ qua dòng lỗi.

Trước khi share màn hình: `cliphist pause`.

## Debug

`CLIPHIST_DEBUG=1 cliphist pick` in ra toạ độ mỗi click cùng khung panel và kết
luận trong/ngoài — dùng khi panel đóng sai lúc.

## Lưu ý bảo mật

`history.db` là **plaintext**. Nó nằm trong `$HOME` với chmod 600, nhưng bất cứ
tiến trình nào chạy dưới user của bạn đều đọc được — coi nó như một file secret.
