use crate::db::Entry;
use crate::util::*;
use std::io::Write;
use std::process::{Command, Stdio};
use std::time::Duration;
use x11_clipboard::Clipboard as X11Clipboard;
use x11rb::protocol::xproto::ConnectionExt as _;

pub const IMAGE_MIMES: [&str; 4] = ["image/png", "image/jpeg", "image/bmp", "image/gif"];

/// Nội dung đọc được từ clipboard.
pub enum Grab {
    Text(String),
    Image(Vec<u8>, &'static str),
    Empty,
}

pub struct Clip {
    c: X11Clipboard,
    ts_atom: u32,
    image_atoms: Vec<(&'static str, u32)>,
}

impl Clip {
    pub fn new() -> Result<Self, String> {
        let c = X11Clipboard::new().map_err(|e| format!("không mở được X11 clipboard: {e}"))?;
        let ts_atom = c
            .getter
            .get_atom("TIMESTAMP")
            .map_err(|e| format!("không lấy được atom TIMESTAMP: {e}"))?;
        let mut image_atoms = Vec::new();
        for m in IMAGE_MIMES {
            if let Ok(a) = c.getter.get_atom(m) {
                image_atoms.push((m, a));
            }
        }
        Ok(Self {
            c,
            ts_atom,
            image_atoms,
        })
    }

    fn load(&self, target: u32, ms: u64) -> Option<Vec<u8>> {
        self.c
            .load(
                self.c.getter.atoms.clipboard,
                target,
                self.c.getter.atoms.property,
                Duration::from_millis(ms),
            )
            .ok()
            .filter(|v| !v.is_empty())
    }

    /// TIMESTAMP của selection: đổi nghĩa là clipboard đã đổi. Rẻ hơn đọc nội dung.
    pub fn signature(&self) -> Option<Vec<u8>> {
        self.load(self.ts_atom, 300)
    }

    /// Cửa sổ đang sở hữu clipboard. Một round-trip X, rất rẻ; đổi chủ =
    /// app khác vừa copy. Cần thiết vì không phải app nào cũng trả TIMESTAMP
    /// (xclip chẳng hạn).
    pub fn owner(&self) -> Option<u32> {
        self.c
            .getter
            .connection
            .get_selection_owner(self.c.getter.atoms.clipboard)
            .ok()?
            .reply()
            .ok()
            .map(|r| r.owner)
            .filter(|w| *w != 0)
    }

    /// Dấu hiệu tổng hợp để biết clipboard có đổi hay chưa.
    pub fn change_token(&self) -> (Option<Vec<u8>>, Option<u32>) {
        (self.signature(), self.owner())
    }

    /// Ưu tiên text; không có text thì thử lần lượt các mime ảnh.
    pub fn grab(&self) -> Grab {
        if let Some(raw) = self.load(self.c.getter.atoms.utf8_string, 600) {
            if let Ok(s) = String::from_utf8(raw) {
                if !s.trim().is_empty() {
                    return Grab::Text(s);
                }
            }
        }
        for (mime, atom) in &self.image_atoms {
            if let Some(data) = self.load(*atom, 2000) {
                return Grab::Image(data, mime);
            }
        }
        Grab::Empty
    }

    /// Đặt nội dung vào clipboard. X11 yêu cầu tiến trình sở hữu selection phải
    /// còn sống, nên hàm này chỉ dùng được trong daemon.
    pub fn put(&self, entry: &Entry) -> Result<(), String> {
        if entry.is_image() {
            let path = entry.path.clone().ok_or("entry ảnh thiếu path")?;
            let data = std::fs::read(&path).map_err(|e| format!("đọc {path}: {e}"))?;
            let mime = entry.mime();
            let atom = self
                .c
                .setter
                .get_atom(&mime)
                .map_err(|e| format!("atom {mime}: {e}"))?;
            self.c
                .store(self.c.setter.atoms.clipboard, atom, data)
                .map_err(|e| format!("store ảnh: {e}"))
        } else {
            self.c
                .store(
                    self.c.setter.atoms.clipboard,
                    self.c.setter.atoms.utf8_string,
                    entry.content.as_bytes(),
                )
                .map_err(|e| format!("store text: {e}"))
        }
    }
}

/// Fallback khi daemon không chạy: nhờ xclip giữ selection (nó tự fork nền).
pub fn xclip_put(entry: &Entry) -> Result<(), String> {
    if which("xclip").is_none() {
        return Err("daemon không chạy và cũng không có xclip".into());
    }
    let (data, mime): (Vec<u8>, String) = if entry.is_image() {
        let path = entry.path.clone().ok_or("entry ảnh thiếu path")?;
        (
            std::fs::read(&path).map_err(|e| e.to_string())?,
            entry.mime(),
        )
    } else {
        (
            entry.content.as_bytes().to_vec(),
            "UTF8_STRING".to_string(),
        )
    };
    let mut ch = Command::new("xclip")
        .args(["-selection", "clipboard", "-t", &mime, "-i"])
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| e.to_string())?;
    ch.stdin
        .as_mut()
        .ok_or("không mở được stdin của xclip")?
        .write_all(&data)
        .map_err(|e| e.to_string())?;
    ch.wait().map_err(|e| e.to_string())?;
    Ok(())
}

/// Ghi nhớ cửa sổ đang focus trước khi mở panel, để dán lại đúng chỗ.
pub fn active_window() -> Option<String> {
    which("xdotool")?;
    let out = Command::new("xdotool").arg("getactivewindow").output().ok()?;
    let s = String::from_utf8_lossy(&out.stdout).trim().to_string();
    if s.chars().all(|c| c.is_ascii_digit()) && !s.is_empty() {
        Some(s)
    } else {
        None
    }
}

pub fn auto_paste(win: Option<String>) {
    if which("xdotool").is_none() {
        eprintln!("[{APP}] thiếu xdotool nên không tự dán được: sudo apt install xdotool");
        return;
    }
    if let Some(w) = win {
        let _ = Command::new("xdotool")
            .args(["windowactivate", "--sync", &w])
            .output();
    }
    std::thread::sleep(Duration::from_millis(150));
    let _ = Command::new("xdotool")
        .args(["key", "--clearmodifiers", "ctrl+v"])
        .status();
}
