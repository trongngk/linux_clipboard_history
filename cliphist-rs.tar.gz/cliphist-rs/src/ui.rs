use crate::db::{self, Entry};
use crate::util::*;
use gtk::gdk;
use gtk::gdk_pixbuf::Pixbuf;
use gtk::glib;
use gtk::prelude::*;
use rusqlite::Connection;
use std::cell::{Cell, RefCell};
use std::collections::HashMap;
use std::rc::Rc;

const W: i32 = 400;
const H: i32 = 560;
const RENDER_CAP: usize = 80;

const CSS: &str = "
window            { background: #2b2b2b; }
.panel            { border: 1px solid #555555; }
.title            { color: #f2f2f2; font-weight: bold; }
.linkish          { color: #9aa0a6; font-size: 90%; }
.linkish:hover    { color: #4cc2ff; }
entry             { background: #3a3a3a; color: #f2f2f2; border: none;
                    border-radius: 6px; padding: 6px 8px; caret-color: #f2f2f2; }
list              { background: transparent; }
list > row        { background: transparent; padding: 0px; }
.card             { background: #343434; border: 1px solid #454545;
                    border-radius: 8px; padding: 8px 10px; margin: 0px 2px 6px 2px; }
list > row:selected .card { background: #3d4f63; border-color: #4cc2ff; }
.card:hover       { background: #3b3b3b; }
.stamp            { color: #9aa0a6; font-size: 80%; }
.stamp-pin        { color: #4cc2ff; font-size: 80%; }
.body             { color: #f2f2f2; font-family: monospace; font-size: 92%; }
.meta             { color: #9aa0a6; font-size: 80%; }
.foot             { color: #9aa0a6; font-size: 80%; }
.iconbtn          { background: transparent; border: none; color: #9aa0a6;
                    padding: 0px 4px; min-height: 0px; min-width: 0px; }
.iconbtn:hover    { color: #ffffff; }
scrollbar         { background: transparent; }
scrollbar slider  { background: #4a4a4a; border-radius: 6px; min-width: 8px; }
";

#[derive(Clone)]
struct Ctx {
    con: Rc<Connection>,
    all: Rc<RefCell<Vec<Entry>>>,
    shown: Rc<RefCell<Vec<Entry>>>,
    result: Rc<RefCell<Option<Entry>>>,
    list: gtk::ListBox,
    search: gtk::Entry,
    foot: gtk::Label,
    pix: Rc<RefCell<HashMap<String, Pixbuf>>>,
}

pub fn pick(con: Rc<Connection>, entries: Vec<Entry>, blur_close: bool) -> Option<Entry> {
    if gtk::init().is_err() {
        eprintln!("[{APP}] không khởi tạo được GTK (DISPLAY chưa set?)");
        return None;
    }
    load_css();

    let win = gtk::Window::new(gtk::WindowType::Toplevel);
    win.set_title("Clipboard history");
    win.set_decorated(false);
    win.set_resizable(false);
    win.set_keep_above(true);
    win.set_skip_taskbar_hint(true);
    win.set_skip_pager_hint(true);
    win.set_type_hint(gdk::WindowTypeHint::Dialog);
    win.set_default_size(W, H);

    let root = gtk::Box::new(gtk::Orientation::Vertical, 0);
    root.style_context().add_class("panel");
    root.set_margin(0);
    win.add(&root);

    // ---- header ----
    let head = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    head.set_margin_top(10);
    head.set_margin_start(12);
    head.set_margin_end(12);
    let title = gtk::Label::new(Some("Lịch sử clipboard"));
    title.style_context().add_class("title");
    title.set_xalign(0.0);
    head.pack_start(&title, true, true, 0);
    let clear = gtk::Button::with_label("Xoá tất cả");
    clear.style_context().add_class("iconbtn");
    clear.style_context().add_class("linkish");
    clear.set_relief(gtk::ReliefStyle::None);
    head.pack_end(&clear, false, false, 0);
    root.pack_start(&head, false, false, 0);

    // ---- ô tìm kiếm ----
    let search = gtk::Entry::new();
    search.set_placeholder_text(Some("Tìm…"));
    search.set_margin_top(8);
    search.set_margin_bottom(8);
    search.set_margin_start(12);
    search.set_margin_end(12);
    root.pack_start(&search, false, false, 0);

    // ---- danh sách ----
    let list = gtk::ListBox::new();
    list.set_selection_mode(gtk::SelectionMode::Browse);
    let scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vscrollbar_policy(gtk::PolicyType::Automatic)
        .margin_start(12)
        .margin_end(6)
        .build();
    scroll.add(&list);
    root.pack_start(&scroll, true, true, 0);

    let foot = gtk::Label::new(None);
    foot.style_context().add_class("foot");
    foot.set_xalign(0.0);
    foot.set_margin_top(6);
    foot.set_margin_bottom(8);
    foot.set_margin_start(12);
    foot.set_margin_end(12);
    root.pack_start(&foot, false, false, 0);

    let ctx = Ctx {
        con,
        all: Rc::new(RefCell::new(entries)),
        shown: Rc::new(RefCell::new(Vec::new())),
        result: Rc::new(RefCell::new(None)),
        list: list.clone(),
        search: search.clone(),
        foot: foot.clone(),
        pix: Rc::new(RefCell::new(HashMap::new())),
    };

    rebuild(&ctx, 0);

    // ---- sự kiện ----
    {
        let ctx = ctx.clone();
        search.connect_changed(move |_| rebuild(&ctx, 0));
    }
    {
        let ctx = ctx.clone();
        search.connect_activate(move |_| accept(&ctx));
    }
    {
        let ctx = ctx.clone();
        list.connect_row_activated(move |_, row| {
            select_index(&ctx, row.index());
            accept(&ctx);
        });
    }
    {
        let ctx = ctx.clone();
        clear.connect_clicked(move |_| {
            let _ = db::wipe(&ctx.con, false);
            *ctx.all.borrow_mut() = db::fetch(&ctx.con, 300).unwrap_or_default();
            rebuild(&ctx, 0);
        });
    }
    {
        let ctx = ctx.clone();
        win.connect_key_press_event(move |_, ev| on_key(&ctx, ev));
    }

    win.connect_delete_event(|_, _| {
        gtk::main_quit();
        glib::Propagation::Proceed
    });

    // Super+V lần 2 -> instance mới gửi SIGTERM -> đóng panel (toggle như Win+V)
    glib::unix_signal_add_local(libc::SIGTERM, || {
        gtk::main_quit();
        glib::ControlFlow::Break
    });

    // Click ra ngoài thì đóng. Hai lớp bảo vệ để không đóng oan:
    //  1. chỉ bật sau 600ms, tức là sau khi panel đã thật sự nhận focus
    //  2. focus-out cũng phát khi focus chuyển sang popup con hoặc quay lại
    //     ngay, nên chờ thêm 200ms rồi kiểm tra is_active() mới quyết định
    let ready = Rc::new(Cell::new(false));
    let grabbed_check: Rc<RefCell<Option<gdk::Seat>>> = Rc::new(RefCell::new(None));
    if blur_close {
        let ready = ready.clone();
        let grabbed = grabbed_check.clone();
        win.connect_focus_out_event(move |w, _| {
            // grab thành công thì click-ra-ngoài đã được button-press lo;
            // focus-out lúc đó chỉ gây đóng oan nên bỏ qua.
            if ready.get() && grabbed.borrow().is_none() {
                let w = w.clone();
                glib::timeout_add_local_once(std::time::Duration::from_millis(200), move || {
                    if !w.is_active() {
                        gtk::main_quit();
                    }
                });
            }
            glib::Propagation::Proceed
        });
    }
    glib::timeout_add_local_once(std::time::Duration::from_millis(600), move || {
        ready.set(true);
    });

    win.show_all();
    place_near_pointer(&win);
    win.present();
    search.grab_focus();

    // Grab con trỏ + bàn phím về panel (đúng cách GTK làm với menu/popover).
    // Nhờ owner_events=true, widget con vẫn nhận event bình thường; còn click
    // ra ngoài panel được gửi tới chính panel với toạ độ âm hoặc vượt kích
    // thước -> đó là dấu hiệu để đóng. Không phụ thuộc WM có trao focus hay
    // không nên đáng tin hơn focus-out-event.
    //
    // show_all() chỉ xếp hàng việc map cửa sổ, X chưa map ngay -> grab lúc này
    // trả về NotViewable. Vì vậy thử lại sau khi vào main loop.
    let seat_holder = grabbed_check.clone();
    if blur_close {
        let w = win.clone();
        let h = seat_holder.clone();
        glib::timeout_add_local_once(std::time::Duration::from_millis(40), move || {
            try_grab(w, h, 0)
        });

        win.add_events(gdk::EventMask::BUTTON_PRESS_MASK);
        win.connect_button_press_event(move |w, ev| {
            // Dùng toạ độ ROOT chứ không phải ev.position(): position() tương
            // đối với GdkWindow nhận event, mà click trong panel có thể được
            // gửi tới viewport con -> so sánh với kích thước toplevel là sai.
            let (rx, ry) = ev.root();
            let (ox, oy) = w.position();
            let (ww, wh) = (w.allocated_width(), w.allocated_height());
            let outside = rx < ox as f64
                || ry < oy as f64
                || rx > (ox + ww) as f64
                || ry > (oy + wh) as f64;
            if std::env::var_os("CLIPHIST_DEBUG").is_some() {
                eprintln!(
                    "[{APP}] click root=({:.0},{:.0}) panel=({},{} {}x{}) outside={}",
                    rx, ry, ox, oy, ww, wh, outside
                );
            }
            if outside {
                gtk::main_quit();
                return glib::Propagation::Stop;
            }
            glib::Propagation::Proceed
        });
    }

    // Lưới an toàn: panel grab cả chuột và bàn phím, nên nếu có bug nào làm nó
    // treo thì desktop sẽ mất input tới khi tiến trình chết. Tự đóng sau 2 phút
    // — panel này không có lý do gì mở lâu thế.
    if blur_close {
        glib::timeout_add_local_once(std::time::Duration::from_secs(120), || {
            eprintln!("[{APP}] tự đóng sau 120s không dùng");
            gtk::main_quit();
        });
    }

    gtk::main();

    // Nhả grab và huỷ cửa sổ TRƯỚC khi trả về, vì ngay sau đây caller sẽ gọi
    // xdotool ctrl+v — grab bàn phím còn treo thì phím sẽ bị chặn lại, và cửa
    // sổ còn nằm trên cùng thì phím có thể bay vào chính nó.
    if let Some(seat) = seat_holder.borrow_mut().take() {
        seat.ungrab();
    }
    unsafe {
        win.destroy();
    }
    while gtk::events_pending() {
        gtk::main_iteration_do(false);
    }

    let picked = ctx.result.borrow().clone();
    picked
}

/// Thử grab seat về cửa sổ, thử lại tối đa ~10 lần vì X cần thời gian map.
fn try_grab(win: gtk::Window, holder: Rc<RefCell<Option<gdk::Seat>>>, attempt: u32) {
    let (Some(gw), Some(seat)) = (
        win.window(),
        gdk::Display::default().and_then(|d| d.default_seat()),
    ) else {
        return;
    };
    let status = seat.grab(&gw, gdk::SeatCapabilities::ALL, true, None, None, None);
    if status == gdk::GrabStatus::Success {
        *holder.borrow_mut() = Some(seat);
        return;
    }
    if attempt < 10 {
        glib::timeout_add_local_once(std::time::Duration::from_millis(50), move || {
            try_grab(win, holder, attempt + 1)
        });
    } else {
        eprintln!("[{APP}] không grab được con trỏ ({:?}); dùng focus-out thay thế", status);
    }
}

fn load_css() {
    let provider = gtk::CssProvider::new();
    if provider.load_from_data(CSS.as_bytes()).is_err() {
        return;
    }
    if let Some(screen) = gdk::Screen::default() {
        gtk::StyleContext::add_provider_for_screen(
            &screen,
            &provider,
            gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
        );
    }
}

fn place_near_pointer(win: &gtk::Window) {
    let Some(display) = gdk::Display::default() else { return };
    let Some(seat) = display.default_seat() else { return };
    let Some(pointer) = seat.pointer() else { return };
    let (_s, px, py) = pointer.position();
    let (mut x, mut y) = (px - W / 2, py - 40);
    if let Some(mon) = display.monitor_at_point(px, py) {
        let g = mon.geometry();
        x = x.clamp(g.x() + 8, g.x() + g.width() - W - 8);
        y = y.clamp(g.y() + 8, g.y() + g.height() - H - 8);
    }
    win.move_(x, y);
}

fn card_text(e: &Entry) -> String {
    let lines: Vec<&str> = e.content.trim().lines().collect();
    let joined = lines
        .iter()
        .take(4)
        .map(|l| l.trim_end())
        .collect::<Vec<_>>()
        .join("\n");
    let mut out = truncate(&joined, 260);
    if lines.len() > 4 && !out.ends_with('…') {
        out.push_str(" …");
    }
    if out.trim().is_empty() {
        "(trống)".to_string()
    } else {
        out
    }
}

fn thumbnail(ctx: &Ctx, path: &str) -> Option<Pixbuf> {
    if let Some(p) = ctx.pix.borrow().get(path) {
        return Some(p.clone());
    }
    let pb = Pixbuf::from_file_at_scale(path, 330, 150, true).ok()?;
    ctx.pix.borrow_mut().insert(path.to_string(), pb.clone());
    Some(pb)
}

fn build_row(ctx: &Ctx, e: &Entry, n: usize) -> gtk::ListBoxRow {
    let row = gtk::ListBoxRow::new();
    let card = gtk::Box::new(gtk::Orientation::Vertical, 4);
    card.style_context().add_class("card");

    let bar = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    let mut stamp = format!("{}{}", if e.pinned { "★ " } else { "" }, human_age(e.ts));
    if n <= 9 {
        stamp.push_str(&format!("   Alt+{}", n));
    }
    let lbl = gtk::Label::new(Some(&stamp));
    lbl.set_xalign(0.0);
    lbl.style_context()
        .add_class(if e.pinned { "stamp-pin" } else { "stamp" });
    bar.pack_start(&lbl, true, true, 0);

    let del = gtk::Button::with_label("✕");
    del.set_relief(gtk::ReliefStyle::None);
    del.style_context().add_class("iconbtn");
    let pin = gtk::Button::with_label(if e.pinned { "★" } else { "☆" });
    pin.set_relief(gtk::ReliefStyle::None);
    pin.style_context().add_class("iconbtn");
    bar.pack_end(&del, false, false, 0);
    bar.pack_end(&pin, false, false, 0);
    card.pack_start(&bar, false, false, 0);

    if e.is_image() {
        match e.path.as_deref().and_then(|p| thumbnail(ctx, p)) {
            Some(pb) => {
                let img = gtk::Image::from_pixbuf(Some(&pb));
                img.set_halign(gtk::Align::Start);
                card.pack_start(&img, false, false, 0);
            }
            None => {
                let l = gtk::Label::new(Some("🖼  (không xem trước được)"));
                l.set_xalign(0.0);
                l.style_context().add_class("body");
                card.pack_start(&l, false, false, 0);
            }
        }
        let meta = gtk::Label::new(Some(&e.meta_text()));
        meta.set_xalign(0.0);
        meta.style_context().add_class("meta");
        card.pack_start(&meta, false, false, 0);
    } else {
        let body = gtk::Label::new(Some(&card_text(e)));
        body.set_xalign(0.0);
        body.set_line_wrap(true);
        body.set_line_wrap_mode(gtk::pango::WrapMode::WordChar);
        body.set_max_width_chars(46);
        body.style_context().add_class("body");
        card.pack_start(&body, false, false, 0);
    }

    row.add(&card);

    let id = e.id;
    let pinned = e.pinned;
    {
        let ctx = ctx.clone();
        del.connect_clicked(move |_| {
            let _ = db::delete(&ctx.con, id);
            ctx.all.borrow_mut().retain(|x| x.id != id);
            let keep = ctx.list.selected_row().map(|r| r.index()).unwrap_or(0);
            rebuild(&ctx, keep);
        });
    }
    {
        let ctx = ctx.clone();
        pin.connect_clicked(move |_| {
            let _ = db::set_pinned(&ctx.con, id, !pinned);
            *ctx.all.borrow_mut() = db::fetch(&ctx.con, 300).unwrap_or_default();
            rebuild(&ctx, 0);
        });
    }
    row
}

fn rebuild(ctx: &Ctx, keep: i32) {
    for child in ctx.list.children() {
        unsafe {
            child.destroy();
        }
    }
    let q = ctx.search.text().to_lowercase();
    let terms: Vec<&str> = q.split_whitespace().collect();

    let mut shown = Vec::new();
    for e in ctx.all.borrow().iter() {
        let hay = if e.is_image() {
            e.label(999).to_lowercase()
        } else {
            e.content.to_lowercase()
        };
        if terms.iter().all(|t| hay.contains(t)) {
            shown.push(e.clone());
        }
    }
    shown.truncate(RENDER_CAP);

    for (i, e) in shown.iter().enumerate() {
        let row = build_row(ctx, e, i + 1);
        ctx.list.add(&row);
    }
    ctx.list.show_all();

    let total = ctx.all.borrow().len();
    ctx.foot.set_text(&format!(
        "{}/{} mục  •  Enter chép  •  Ctrl+P ghim  •  Delete xoá  •  Esc đóng",
        shown.len(),
        total
    ));
    *ctx.shown.borrow_mut() = shown;

    let n = ctx.shown.borrow().len() as i32;
    if n > 0 {
        select_index(ctx, keep.clamp(0, n - 1));
    }
}

fn select_index(ctx: &Ctx, i: i32) {
    if let Some(row) = ctx.list.row_at_index(i) {
        ctx.list.select_row(Some(&row));
        row.grab_focus();
        ctx.search.grab_focus_without_selecting();
    }
}

fn selected(ctx: &Ctx) -> Option<Entry> {
    let i = ctx.list.selected_row()?.index();
    ctx.shown.borrow().get(i as usize).cloned()
}

fn accept(ctx: &Ctx) {
    if let Some(e) = selected(ctx) {
        *ctx.result.borrow_mut() = Some(e);
    }
    gtk::main_quit();
}

fn move_sel(ctx: &Ctx, delta: i32) {
    let n = ctx.shown.borrow().len() as i32;
    if n == 0 {
        return;
    }
    let cur = ctx.list.selected_row().map(|r| r.index()).unwrap_or(0);
    select_index(ctx, (cur + delta).clamp(0, n - 1));
}

fn on_key(ctx: &Ctx, ev: &gdk::EventKey) -> glib::Propagation {
    use gdk::keys::constants as k;
    let key = ev.keyval();
    let state = ev.state();
    let ctrl = state.contains(gdk::ModifierType::CONTROL_MASK);
    let alt = state.contains(gdk::ModifierType::MOD1_MASK);

    // Alt+1..9: chọn nhanh
    if alt {
        if let Some(c) = key.to_unicode() {
            if ('1'..='9').contains(&c) {
                let idx = c as i32 - '1' as i32;
                if idx < ctx.shown.borrow().len() as i32 {
                    select_index(ctx, idx);
                    accept(ctx);
                }
                return glib::Propagation::Stop;
            }
        }
    }

    match key {
        k::Escape => {
            gtk::main_quit();
            glib::Propagation::Stop
        }
        k::Return | k::KP_Enter => {
            accept(ctx);
            glib::Propagation::Stop
        }
        k::Down => {
            move_sel(ctx, 1);
            glib::Propagation::Stop
        }
        k::Up => {
            move_sel(ctx, -1);
            glib::Propagation::Stop
        }
        k::Page_Down => {
            move_sel(ctx, 5);
            glib::Propagation::Stop
        }
        k::Page_Up => {
            move_sel(ctx, -5);
            glib::Propagation::Stop
        }
        k::Delete => {
            if let Some(e) = selected(ctx) {
                let _ = db::delete(&ctx.con, e.id);
                ctx.all.borrow_mut().retain(|x| x.id != e.id);
                let keep = ctx.list.selected_row().map(|r| r.index()).unwrap_or(0);
                rebuild(ctx, keep);
            }
            glib::Propagation::Stop
        }
        k::p if ctrl => {
            if let Some(e) = selected(ctx) {
                let _ = db::set_pinned(&ctx.con, e.id, !e.pinned);
                *ctx.all.borrow_mut() = db::fetch(&ctx.con, 300).unwrap_or_default();
                rebuild(ctx, 0);
            }
            glib::Propagation::Stop
        }
        _ => glib::Propagation::Proceed,
    }
}
