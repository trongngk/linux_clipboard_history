mod clip;
mod daemon;
mod db;
mod ipc;
mod ui;
mod util;

use std::process::Command;
use std::rc::Rc;
use util::*;

const HELP: &str = "\
cliphist — clipboard history cho Linux Mint / Cinnamon (X11), giống Win+V

    cliphist install [--hotkey <Super>v]   cài autostart + hotkey Cinnamon
    cliphist daemon [--interval MS]        chạy nền, ghi lịch sử + giữ clipboard
    cliphist pick [--paste] [--stay]       mở panel chọn (--stay: click ra ngoài không đóng)
    cliphist set blur-close on|off         đặt mặc định cho việc click ra ngoài
    cliphist set max-entries N             số bản ghi giữ lại (mặc định 20)
    cliphist list [-n N]                   in lịch sử
    cliphist get <id>                      in nội dung (ảnh: in đường dẫn)
    cliphist copy <id>                     chép entry vào clipboard
    cliphist wipe [--all]                  xoá lịch sử (--all: xoá cả mục đã ghim)
    cliphist pause | resume                tạm dừng / bật lại việc ghi
    cliphist doctor                        kiểm tra môi trường
    cliphist uninstall                     gỡ autostart

Yêu cầu: xdotool (để tự dán). xclip chỉ cần khi daemon không chạy.
";

fn main() {
    // Rust ignore SIGPIPE mặc định, nên `cliphist list | head -1` sẽ panic khi
    // head đóng pipe. Trả lại hành vi Unix bình thường: chết im lặng.
    unsafe {
        libc::signal(libc::SIGPIPE, libc::SIG_DFL);
    }

    let args: Vec<String> = std::env::args().skip(1).collect();
    let cmd = args.first().map(|s| s.as_str()).unwrap_or("help");
    let rest: &[String] = if args.is_empty() { &[] } else { &args[1..] };

    let code = match cmd {
        "daemon" => cmd_daemon(rest),
        "pick" => cmd_pick(rest),
        "list" => cmd_list(rest),
        "get" => cmd_get(rest),
        "copy" => cmd_copy(rest),
        "wipe" => cmd_wipe(rest),
        "set" => cmd_set(rest),
        "pause" => cmd_pause(),
        "resume" => cmd_resume(),
        "doctor" => cmd_doctor(),
        "install" => cmd_install(rest),
        "uninstall" => cmd_uninstall(),
        "-h" | "--help" | "help" => {
            print!("{HELP}");
            0
        }
        other => {
            eprintln!("lệnh lạ: {other}\n");
            print!("{HELP}");
            2
        }
    };
    std::process::exit(code);
}

fn flag_value(args: &[String], name: &str) -> Option<String> {
    let i = args.iter().position(|a| a == name)?;
    args.get(i + 1).cloned()
}

fn has_flag(args: &[String], name: &str) -> bool {
    args.iter().any(|a| a == name)
}

fn positional(args: &[String]) -> Option<&String> {
    args.iter().find(|a| !a.starts_with('-'))
}

fn cmd_daemon(args: &[String]) -> i32 {
    let interval = flag_value(args, "--interval")
        .or_else(|| flag_value(args, "-i"))
        .and_then(|v| v.parse::<u64>().ok())
        .unwrap_or(400);
    match daemon::run(interval) {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("[{APP}] {e}");
            1
        }
    }
}

fn cmd_pick(args: &[String]) -> i32 {
    // instance thứ 2 = đóng panel đang mở (toggle giống Win+V)
    let _lock = match acquire_lock(&pick_lock()) {
        Ok(LockResult::Acquired(l)) => l,
        Ok(LockResult::Held(pid)) => {
            if let Some(p) = pid {
                kill(p);
            }
            return 0;
        }
        Err(e) => {
            eprintln!("[{APP}] lock lỗi: {e}");
            return 1;
        }
    };

    let con = match db::open() {
        Ok(c) => Rc::new(c),
        Err(e) => {
            eprintln!("[{APP}] mở DB lỗi: {e}");
            return 1;
        }
    };
    let entries = db::fetch(&con, 300).unwrap_or_default();
    if entries.is_empty() {
        eprintln!("[{APP}] lịch sử trống — daemon đã chạy chưa? (cliphist daemon)");
        return 1;
    }

    // --stay ghi đè setting; mặc định lấy từ settings.conf (blur_close=true)
    let blur_close = if has_flag(args, "--stay") || has_flag(args, "--no-blur-close") {
        false
    } else {
        setting_bool("blur_close", true)
    };

    let target = clip::active_window();
    let chosen = match ui::pick(con, entries, blur_close) {
        Some(e) => e,
        None => return 0,
    };

    if let Err(e) = put(&chosen) {
        eprintln!("[{APP}] {e}");
        return 1;
    }
    if has_flag(args, "--paste") {
        clip::auto_paste(target);
    }
    0
}

/// Daemon sở hữu X selection nên nhờ nó set; không có thì nhờ xclip.
fn put(entry: &db::Entry) -> Result<(), String> {
    match ipc::client_set(entry.id) {
        Ok(()) => Ok(()),
        Err(_) => clip::xclip_put(entry),
    }
}

fn cmd_list(args: &[String]) -> i32 {
    let n = flag_value(args, "-n")
        .or_else(|| flag_value(args, "--number"))
        .and_then(|v| v.parse::<i64>().ok())
        .unwrap_or(25);
    let con = match db::open() {
        Ok(c) => c,
        Err(e) => {
            eprintln!("{e}");
            return 1;
        }
    };
    for e in db::fetch(&con, n).unwrap_or_default() {
        println!(
            "{:>5} {} {:>4}  {}",
            e.id,
            if e.pinned { "★" } else { " " },
            human_age(e.ts),
            e.label(100)
        );
    }
    0
}

fn cmd_get(args: &[String]) -> i32 {
    let id = match positional(args).and_then(|s| s.parse::<i64>().ok()) {
        Some(i) => i,
        None => {
            eprintln!("cần id, ví dụ: cliphist get 12");
            return 2;
        }
    };
    let con = match db::open() {
        Ok(c) => c,
        Err(_) => return 1,
    };
    match db::get(&con, id) {
        Ok(Some(e)) => {
            if e.is_image() {
                println!("{}", e.path.unwrap_or_default());
            } else {
                print!("{}", e.content);
            }
            0
        }
        _ => {
            eprintln!("không có entry id={id}");
            1
        }
    }
}

fn cmd_copy(args: &[String]) -> i32 {
    let id = match positional(args).and_then(|s| s.parse::<i64>().ok()) {
        Some(i) => i,
        None => {
            eprintln!("cần id, ví dụ: cliphist copy 12");
            return 2;
        }
    };
    let con = match db::open() {
        Ok(c) => c,
        Err(_) => return 1,
    };
    match db::get(&con, id) {
        Ok(Some(e)) => match put(&e) {
            Ok(()) => 0,
            Err(err) => {
                eprintln!("[{APP}] {err}");
                1
            }
        },
        _ => {
            eprintln!("không có entry id={id}");
            1
        }
    }
}

fn cmd_wipe(args: &[String]) -> i32 {
    let con = match db::open() {
        Ok(c) => c,
        Err(_) => return 1,
    };
    let all = has_flag(args, "--all");
    match db::wipe(&con, all) {
        Ok(()) => {
            println!(
                "Đã xoá lịch sử.{}",
                if all { "" } else { " (giữ lại mục đã ghim)" }
            );
            0
        }
        Err(e) => {
            eprintln!("{e}");
            1
        }
    }
}

fn cmd_set(args: &[String]) -> i32 {
    let key = args.first().map(|s| s.as_str()).unwrap_or("");
    let val = args.get(1).map(|s| s.as_str()).unwrap_or("");
    match (key, val) {
        ("blur-close", v @ ("on" | "off")) => {
            let on = v == "on";
            if let Err(e) = set_setting("blur_close", if on { "true" } else { "false" }) {
                eprintln!("ghi settings lỗi: {}", e);
                return 1;
            }
            println!(
                "blur-close = {} — click ra ngoài {} panel.",
                v,
                if on { "sẽ đóng" } else { "KHÔNG đóng" }
            );
            println!("File: {}", settings_file().display());
            0
        }
        ("max-entries", v) => match v.parse::<usize>() {
            Ok(n) if n > 0 => {
                if let Err(e) = set_setting("max_entries", &n.to_string()) {
                    eprintln!("ghi settings lỗi: {}", e);
                    return 1;
                }
                // áp dụng ngay cho dữ liệu đang có
                match db::open().and_then(|c| db::trim(&c).map(|_| c)) {
                    Ok(con) => {
                        let left: i64 = con
                            .query_row("SELECT COUNT(*) FROM entries", [], |r| r.get(0))
                            .unwrap_or(0);
                        println!("max-entries = {} (hiện còn {} bản ghi)", n, left);
                    }
                    Err(e) => eprintln!("trim lỗi: {}", e),
                }
                println!("File: {}", settings_file().display());
                0
            }
            _ => {
                eprintln!("cần một số nguyên dương, ví dụ: cliphist set max-entries 20");
                2
            }
        },
        ("blur-close", other) => {
            eprintln!("giá trị phải là on hoặc off (nhận được: {:?})", other);
            2
        }
        _ => {
            eprintln!("cách dùng:");
            eprintln!("  cliphist set blur-close on|off");
            eprintln!("  cliphist set max-entries N");
            2
        }
    }
}

fn cmd_pause() -> i32 {
    let _ = ensure_dirs();
    let _ = std::fs::write(pause_flag(), b"");
    println!("Đã tạm dừng ghi clipboard. Bật lại: cliphist resume");
    0
}

fn cmd_resume() -> i32 {
    let _ = std::fs::remove_file(pause_flag());
    println!("Đã bật lại ghi clipboard.");
    0
}

fn cmd_doctor() -> i32 {
    println!(
        "DISPLAY        = {}",
        std::env::var("DISPLAY").unwrap_or_else(|_| "(chưa set)".into())
    );
    for bin in ["xdotool", "xclip", "gsettings"] {
        println!(
            "{:<14} = {}",
            bin,
            which(bin)
                .map(|p| p.display().to_string())
                .unwrap_or_else(|| "THIẾU".into())
        );
    }
    println!(
        "daemon         = {}",
        if ipc::daemon_alive() {
            "đang chạy"
        } else {
            "KHÔNG chạy (clipboard sẽ do xclip giữ)"
        }
    );
    match clip::Clip::new() {
        Ok(c) => {
            println!(
                "X11 clipboard  = OK (TIMESTAMP: {})",
                if c.signature().is_some() {
                    "có"
                } else {
                    "không, dùng fallback"
                }
            );
            match c.grab() {
                clip::Grab::Text(t) => println!("nội dung hiện tại = text ({} bytes)", t.len()),
                clip::Grab::Image(d, m) => {
                    println!("nội dung hiện tại = {} ({})", m, human_bytes(d.len()))
                }
                clip::Grab::Empty => println!("nội dung hiện tại = (rỗng)"),
            }
        }
        Err(e) => println!("X11 clipboard  = LỖI: {e}"),
    }
    match db::open() {
        Ok(con) => {
            let t: i64 = con
                .query_row("SELECT COUNT(*) FROM entries WHERE kind='text'", [], |r| {
                    r.get(0)
                })
                .unwrap_or(0);
            let i: i64 = con
                .query_row("SELECT COUNT(*) FROM entries WHERE kind='image'", [], |r| {
                    r.get(0)
                })
                .unwrap_or(0);
            let pinned: i64 = con
                .query_row("SELECT COUNT(*) FROM entries WHERE pinned=1", [], |r| r.get(0))
                .unwrap_or(0);
            println!(
                "DB             = {} ({} text, {} ảnh, {} ghim)",
                db_path().display(),
                t,
                i,
                pinned
            );
            println!(
                "max-entries    = {} (mục ghim không tính) | blur-close = {}",
                db::max_entries(),
                if setting_bool("blur_close", true) { "on" } else { "off" }
            );
            println!(
                "blur-close     = {}",
                if setting_bool("blur_close", true) { "on" } else { "off" }
            );
        }
        Err(e) => println!("DB             = LỖI: {e}"),
    }
    0
}

fn autostart_path() -> std::path::PathBuf {
    home().join(".config/autostart/cliphist-lite.desktop")
}

fn cmd_install(args: &[String]) -> i32 {
    let _ = ensure_dirs();
    let hotkey = flag_value(args, "--hotkey").unwrap_or_else(|| "<Super>v".to_string());
    let exe = match std::env::current_exe() {
        Ok(p) => p,
        Err(e) => {
            eprintln!("không xác định được đường dẫn binary: {e}");
            return 1;
        }
    };

    if let Some(parent) = autostart_path().parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let desktop = format!(
        "[Desktop Entry]\nType=Application\nName=Clipboard History Daemon\n\
         Exec={} daemon\nX-GNOME-Autostart-enabled=true\nNoDisplay=true\n",
        exe.display()
    );
    if let Err(e) = std::fs::write(autostart_path(), desktop) {
        eprintln!("ghi autostart lỗi: {e}");
        return 1;
    }
    println!("✓ Autostart: {}", autostart_path().display());

    if which("gsettings").is_some() {
        install_hotkey(&exe, &hotkey);
    } else {
        eprintln!("[{APP}] không thấy gsettings — tự gán hotkey trong Settings > Keyboard.");
    }
    println!("\nKhởi động daemon ngay:");
    println!("  nohup {} daemon >/tmp/cliphist.log 2>&1 &", exe.display());
    0
}

fn gsettings_get(schema: &str, key: &str, path: Option<&str>) -> String {
    let target = match path {
        Some(p) => format!("{}:{}", schema, p),
        None => schema.to_string(),
    };
    Command::new("gsettings")
        .args(["get", &target, key])
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_default()
}

fn gsettings_set(schema: &str, key: &str, value: &str, path: Option<&str>) {
    let target = match path {
        Some(p) => format!("{}:{}", schema, p),
        None => schema.to_string(),
    };
    let _ = Command::new("gsettings")
        .args(["set", &target, key, value])
        .status();
}

fn install_hotkey(exe: &std::path::Path, hotkey: &str) {
    const SCHEMA: &str = "org.cinnamon.desktop.keybindings";
    let raw = gsettings_get(SCHEMA, "custom-list", None);
    let mut existing: Vec<String> = raw
        .trim_start_matches("@as")
        .trim()
        .trim_matches(|c| c == '[' || c == ']')
        .split(',')
        .map(|s| s.trim().trim_matches('\'').to_string())
        .filter(|s| !s.is_empty())
        .collect();

    let mut slot = String::from("custom0");
    let mut i = 0;
    while existing.contains(&slot) {
        let p = format!("/org/cinnamon/desktop/keybindings/custom-keybindings/{}/", slot);
        let cmdline = gsettings_get(&format!("{}.custom-keybinding", SCHEMA), "command", Some(&p));
        if cmdline.contains("cliphist") {
            break;
        }
        i += 1;
        slot = format!("custom{}", i);
    }

    let path = format!("/org/cinnamon/desktop/keybindings/custom-keybindings/{}/", slot);
    let kb = format!("{}.custom-keybinding", SCHEMA);
    gsettings_set(&kb, "name", "'Clipboard History'", Some(&path));
    gsettings_set(
        &kb,
        "command",
        &format!("'{} pick --paste'", exe.display()),
        Some(&path),
    );
    gsettings_set(&kb, "binding", &format!("['{}']", hotkey), Some(&path));

    if !existing.contains(&slot) {
        existing.push(slot.clone());
    }
    let list = format!(
        "[{}]",
        existing
            .iter()
            .map(|s| format!("'{}'", s))
            .collect::<Vec<_>>()
            .join(", ")
    );
    gsettings_set(SCHEMA, "custom-list", &list, None);
    println!("✓ Hotkey {} → {}", hotkey, slot);
}

fn cmd_uninstall() -> i32 {
    let _ = std::fs::remove_file(autostart_path());
    println!("✓ Đã gỡ autostart. Hotkey gỡ trong Settings > Keyboard > Shortcuts.");
    println!(
        "  Dữ liệu vẫn ở {} (xoá: rm -rf {})",
        data_dir().display(),
        data_dir().display()
    );
    0
}
